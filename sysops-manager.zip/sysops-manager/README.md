# ⚙️ SysOps Manager

Aplicación de escritorio local para gestión de sistemas bancarios.
Desarrollada en **Java 21 + JavaFX + SQLite**.

---

## 📋 Requisitos

- Java 21 (JDK)
- Maven 3.8+
- IntelliJ IDEA o VS Code con extensión Java

---

## 🚀 Cómo ejecutar

```bash
# Clonar o descomprimir el proyecto
cd sysops-manager

# Compilar
mvn compile

# Ejecutar (modo desarrollo)
mvn javafx:run

# Generar JAR ejecutable
mvn package
java -jar target/sysops-manager-1.0.0.jar
```

---

## 📁 Ubicación de datos

La base de datos SQLite se guarda automáticamente en:

- **Windows:** `C:\Users\TuUsuario\.sysops-manager\sysops.db`
- **Linux:**   `/home/tuusuario/.sysops-manager/sysops.db`

Para **migrar datos** a otra PC: copiar el archivo `sysops.db`.  
Para **respaldar**: copiar ese mismo archivo.

---

## 🔐 Seguridad - Gestor de Contraseñas

- Las contraseñas se encriptan con **AES-256-GCM** antes de guardarse.
- La clave se deriva de tu contraseña maestra usando **PBKDF2-SHA256** con 310.000 iteraciones.
- **Primera vez**: define tu contraseña maestra al abrir el módulo.
- Las contraseñas visibles se **ocultan automáticamente** en 30 segundos.
- El vault se **bloquea automáticamente** tras 5 minutos de inactividad.
- **NUNCA** se guarda la contraseña maestra en texto plano.

---

## 📦 Módulos

| Módulo | Descripción |
|--------|-------------|
| **Dashboard** | Resumen general con estadísticas y últimas actividades |
| **Correctivos** | Gestión de errores/tickets con ticket, descripción, solución, prioridad |
| **Servidores** | Catálogo de servidores con IP, ambiente (PRD/QA/DEV), tipo, SO |
| **Contraseñas** | Vault encriptado AES-256. Requiere contraseña maestra para ver |
| **Tareas** | To-do list con prioridad, estado, fecha límite. Marcar como completada |
| **Notas** | Editor libre con etiquetas, fijado y búsqueda |
| **Comandos** | Biblioteca de comandos con copia rápida al portapapeles |

---

## 🛠️ Stack Tecnológico

- **Java 21** — Lenguaje principal
- **JavaFX 21** — Interfaz gráfica
- **AtlantaFX** — Tema oscuro moderno
- **SQLite** — Base de datos local (1 archivo)
- **JDBI3** — Acceso a datos simple y limpio
- **AES-256-GCM** — Encriptación de contraseñas (javax.crypto nativo)

---

## 🔧 Estructura del Proyecto

```
src/main/java/com/sysops/
├── App.java                    ← Entry point JavaFX
├── config/DatabaseConfig.java  ← SQLite init + tablas
├── models/                     ← POJOs (Correctivo, Servidor, etc.)
├── modules/                    ← DAOs por módulo
│   ├── correctivos/
│   ├── servidores/
│   ├── passwords/
│   ├── tareas/
│   ├── notas/
│   └── comandos/
├── controllers/                ← Controladores JavaFX
└── utils/CryptoUtil.java       ← AES-256-GCM
```
