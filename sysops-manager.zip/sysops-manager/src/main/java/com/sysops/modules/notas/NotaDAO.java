package com.sysops.modules.notas;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.Nota;
import org.jdbi.v3.core.Jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class NotaDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    public List<Nota> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM notas ORDER BY fijada DESC, actualizado_en DESC")
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public List<Nota> search(String query) {
        String q = "%" + query + "%";
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM notas
                WHERE titulo LIKE :q OR contenido LIKE :q OR etiquetas LIKE :q
                ORDER BY fijada DESC, actualizado_en DESC
            """)
             .bind("q", q)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public int insert(Nota n) {
        return jdbi.withHandle(h ->
            h.createUpdate("""
                INSERT INTO notas (titulo, contenido, etiquetas, color, fijada)
                VALUES (:titulo, :contenido, :etiquetas, :color, :fijada)
            """)
             .bind("titulo",    n.getTitulo())
             .bind("contenido", n.getContenido())
             .bind("etiquetas", n.getEtiquetas())
             .bind("color",     n.getColor())
             .bind("fijada",    n.isFijada() ? 1 : 0)
             .executeAndReturnGeneratedKeys("id")
             .mapTo(Integer.class).one()
        );
    }

    public void update(Nota n) {
        jdbi.withHandle(h ->
            h.createUpdate("""
                UPDATE notas SET
                  titulo=:titulo, contenido=:contenido, etiquetas=:etiquetas,
                  color=:color, fijada=:fijada,
                  actualizado_en=datetime('now','localtime')
                WHERE id=:id
            """)
             .bind("id",        n.getId())
             .bind("titulo",    n.getTitulo())
             .bind("contenido", n.getContenido())
             .bind("etiquetas", n.getEtiquetas())
             .bind("color",     n.getColor())
             .bind("fijada",    n.isFijada() ? 1 : 0)
             .execute()
        );
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM notas WHERE id = :id")
             .bind("id", id).execute()
        );
    }

    private Nota mapRow(ResultSet rs) throws SQLException {
        Nota n = new Nota();
        n.setId(rs.getInt("id"));
        n.setTitulo(rs.getString("titulo"));
        n.setContenido(rs.getString("contenido"));
        n.setEtiquetas(rs.getString("etiquetas"));
        n.setColor(rs.getString("color"));
        n.setFijada(rs.getInt("fijada") == 1);
        n.setCreadoEn(rs.getString("creado_en"));
        n.setActualizadoEn(rs.getString("actualizado_en"));
        return n;
    }
}
