package com.sysops.modules.correctivos;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.Correctivo;
import org.jdbi.v3.core.Jdbi;

import java.util.List;
import java.util.Optional;

public class CorrectivoDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    public List<Correctivo> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM correctivos ORDER BY creado_en DESC")
             .map((rs, ctx) -> mapRow(rs))
             .list()
        );
    }

    public List<Correctivo> findByEstado(String estado) {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM correctivos WHERE estado = :estado ORDER BY creado_en DESC")
             .bind("estado", estado)
             .map((rs, ctx) -> mapRow(rs))
             .list()
        );
    }

    public List<Correctivo> search(String query) {
        String q = "%" + query + "%";
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM correctivos
                WHERE titulo LIKE :q OR ticket LIKE :q OR descripcion LIKE :q
                   OR servidor LIKE :q OR etiquetas LIKE :q
                ORDER BY creado_en DESC
            """)
             .bind("q", q)
             .map((rs, ctx) -> mapRow(rs))
             .list()
        );
    }

    public Optional<Correctivo> findById(int id) {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM correctivos WHERE id = :id")
             .bind("id", id)
             .map((rs, ctx) -> mapRow(rs))
             .findFirst()
        );
    }

    public int insert(Correctivo c) {
        return jdbi.withHandle(h ->
            h.createUpdate("""
                INSERT INTO correctivos
                  (ticket, titulo, descripcion, solucion, servidor, ambiente,
                   estado, prioridad, fecha_inicio, fecha_cierre, tiempo_resolucion, etiquetas)
                VALUES
                  (:ticket, :titulo, :descripcion, :solucion, :servidor, :ambiente,
                   :estado, :prioridad, :fechaInicio, :fechaCierre, :tiempoResolucion, :etiquetas)
            """)
             .bind("ticket",           c.getTicket())
             .bind("titulo",           c.getTitulo())
             .bind("descripcion",      c.getDescripcion())
             .bind("solucion",         c.getSolucion())
             .bind("servidor",         c.getServidor())
             .bind("ambiente",         c.getAmbiente())
             .bind("estado",           c.getEstado())
             .bind("prioridad",        c.getPrioridad())
             .bind("fechaInicio",      c.getFechaInicio())
             .bind("fechaCierre",      c.getFechaCierre())
             .bind("tiempoResolucion", c.getTiempoResolucion())
             .bind("etiquetas",        c.getEtiquetas())
             .executeAndReturnGeneratedKeys("id")
             .mapTo(Integer.class)
             .one()
        );
    }

    public void update(Correctivo c) {
        jdbi.withHandle(h ->
            h.createUpdate("""
                UPDATE correctivos SET
                  ticket=:ticket, titulo=:titulo, descripcion=:descripcion,
                  solucion=:solucion, servidor=:servidor, ambiente=:ambiente,
                  estado=:estado, prioridad=:prioridad, fecha_inicio=:fechaInicio,
                  fecha_cierre=:fechaCierre, tiempo_resolucion=:tiempoResolucion,
                  etiquetas=:etiquetas,
                  actualizado_en=datetime('now','localtime')
                WHERE id=:id
            """)
             .bind("id",               c.getId())
             .bind("ticket",           c.getTicket())
             .bind("titulo",           c.getTitulo())
             .bind("descripcion",      c.getDescripcion())
             .bind("solucion",         c.getSolucion())
             .bind("servidor",         c.getServidor())
             .bind("ambiente",         c.getAmbiente())
             .bind("estado",           c.getEstado())
             .bind("prioridad",        c.getPrioridad())
             .bind("fechaInicio",      c.getFechaInicio())
             .bind("fechaCierre",      c.getFechaCierre())
             .bind("tiempoResolucion", c.getTiempoResolucion())
             .bind("etiquetas",        c.getEtiquetas())
             .execute()
        );
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM correctivos WHERE id = :id")
             .bind("id", id)
             .execute()
        );
    }

    private Correctivo mapRow(java.sql.ResultSet rs) throws java.sql.SQLException {
        Correctivo c = new Correctivo();
        c.setId(rs.getInt("id"));
        c.setTicket(rs.getString("ticket"));
        c.setTitulo(rs.getString("titulo"));
        c.setDescripcion(rs.getString("descripcion"));
        c.setSolucion(rs.getString("solucion"));
        c.setServidor(rs.getString("servidor"));
        c.setAmbiente(rs.getString("ambiente"));
        c.setEstado(rs.getString("estado"));
        c.setPrioridad(rs.getString("prioridad"));
        c.setFechaInicio(rs.getString("fecha_inicio"));
        c.setFechaCierre(rs.getString("fecha_cierre"));
        c.setTiempoResolucion(rs.getString("tiempo_resolucion"));
        c.setEtiquetas(rs.getString("etiquetas"));
        c.setCreadoEn(rs.getString("creado_en"));
        return c;
    }
}
