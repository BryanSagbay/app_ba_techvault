package com.sysops.modules.tareas;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.Tarea;
import org.jdbi.v3.core.Jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class TareaDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    public List<Tarea> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM tareas
                ORDER BY
                  CASE prioridad WHEN 'URGENTE' THEN 1 WHEN 'ALTA' THEN 2
                                 WHEN 'MEDIA' THEN 3 ELSE 4 END,
                  fecha_limite ASC NULLS LAST
            """)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public List<Tarea> findPendientes() {
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM tareas
                WHERE estado NOT IN ('COMPLETADA', 'CANCELADA')
                ORDER BY
                  CASE prioridad WHEN 'URGENTE' THEN 1 WHEN 'ALTA' THEN 2
                                 WHEN 'MEDIA' THEN 3 ELSE 4 END
            """)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public int insert(Tarea t) {
        return jdbi.withHandle(h ->
            h.createUpdate("""
                INSERT INTO tareas
                  (titulo, descripcion, prioridad, estado, categoria, fecha_limite)
                VALUES
                  (:titulo, :descripcion, :prioridad, :estado, :categoria, :fechaLimite)
            """)
             .bind("titulo",       t.getTitulo())
             .bind("descripcion",  t.getDescripcion())
             .bind("prioridad",    t.getPrioridad())
             .bind("estado",       t.getEstado())
             .bind("categoria",    t.getCategoria())
             .bind("fechaLimite",  t.getFechaLimite())
             .executeAndReturnGeneratedKeys("id")
             .mapTo(Integer.class).one()
        );
    }

    public void update(Tarea t) {
        jdbi.withHandle(h ->
            h.createUpdate("""
                UPDATE tareas SET
                  titulo=:titulo, descripcion=:descripcion, prioridad=:prioridad,
                  estado=:estado, categoria=:categoria, fecha_limite=:fechaLimite,
                  completada_en=:completadaEn
                WHERE id=:id
            """)
             .bind("id",           t.getId())
             .bind("titulo",       t.getTitulo())
             .bind("descripcion",  t.getDescripcion())
             .bind("prioridad",    t.getPrioridad())
             .bind("estado",       t.getEstado())
             .bind("categoria",    t.getCategoria())
             .bind("fechaLimite",  t.getFechaLimite())
             .bind("completadaEn", t.getCompletadaEn())
             .execute()
        );
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM tareas WHERE id = :id")
             .bind("id", id).execute()
        );
    }

    private Tarea mapRow(ResultSet rs) throws SQLException {
        Tarea t = new Tarea();
        t.setId(rs.getInt("id"));
        t.setTitulo(rs.getString("titulo"));
        t.setDescripcion(rs.getString("descripcion"));
        t.setPrioridad(rs.getString("prioridad"));
        t.setEstado(rs.getString("estado"));
        t.setCategoria(rs.getString("categoria"));
        t.setFechaLimite(rs.getString("fecha_limite"));
        t.setCompletadaEn(rs.getString("completada_en"));
        t.setCreadoEn(rs.getString("creado_en"));
        return t;
    }
}
