package com.sysops.modules.servidores;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.Servidor;
import org.jdbi.v3.core.Jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ServidorDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    public List<Servidor> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM servidores ORDER BY ambiente, nombre")
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public List<Servidor> findByAmbiente(String ambiente) {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM servidores WHERE ambiente = :a ORDER BY nombre")
             .bind("a", ambiente)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public List<Servidor> search(String query) {
        String q = "%" + query + "%";
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM servidores
                WHERE nombre LIKE :q OR ip LIKE :q OR descripcion LIKE :q OR tipo LIKE :q
                ORDER BY ambiente, nombre
            """)
             .bind("q", q)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public int insert(Servidor s) {
        return jdbi.withHandle(h ->
            h.createUpdate("""
                INSERT INTO servidores
                  (nombre, ip, ambiente, tipo, puerto, so, descripcion, usuario, notas, activo)
                VALUES
                  (:nombre, :ip, :ambiente, :tipo, :puerto, :so, :descripcion, :usuario, :notas, :activo)
            """)
             .bind("nombre",      s.getNombre())
             .bind("ip",          s.getIp())
             .bind("ambiente",    s.getAmbiente())
             .bind("tipo",        s.getTipo())
             .bind("puerto",      s.getPuerto())
             .bind("so",          s.getSo())
             .bind("descripcion", s.getDescripcion())
             .bind("usuario",     s.getUsuario())
             .bind("notas",       s.getNotas())
             .bind("activo",      s.isActivo() ? 1 : 0)
             .executeAndReturnGeneratedKeys("id")
             .mapTo(Integer.class).one()
        );
    }

    public void update(Servidor s) {
        jdbi.withHandle(h ->
            h.createUpdate("""
                UPDATE servidores SET
                  nombre=:nombre, ip=:ip, ambiente=:ambiente, tipo=:tipo,
                  puerto=:puerto, so=:so, descripcion=:descripcion,
                  usuario=:usuario, notas=:notas, activo=:activo
                WHERE id=:id
            """)
             .bind("id",          s.getId())
             .bind("nombre",      s.getNombre())
             .bind("ip",          s.getIp())
             .bind("ambiente",    s.getAmbiente())
             .bind("tipo",        s.getTipo())
             .bind("puerto",      s.getPuerto())
             .bind("so",          s.getSo())
             .bind("descripcion", s.getDescripcion())
             .bind("usuario",     s.getUsuario())
             .bind("notas",       s.getNotas())
             .bind("activo",      s.isActivo() ? 1 : 0)
             .execute()
        );
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM servidores WHERE id = :id")
             .bind("id", id).execute()
        );
    }

    private Servidor mapRow(ResultSet rs) throws SQLException {
        Servidor s = new Servidor();
        s.setId(rs.getInt("id"));
        s.setNombre(rs.getString("nombre"));
        s.setIp(rs.getString("ip"));
        s.setAmbiente(rs.getString("ambiente"));
        s.setTipo(rs.getString("tipo"));
        s.setPuerto(rs.getInt("puerto"));
        s.setSo(rs.getString("so"));
        s.setDescripcion(rs.getString("descripcion"));
        s.setUsuario(rs.getString("usuario"));
        s.setNotas(rs.getString("notas"));
        s.setActivo(rs.getInt("activo") == 1);
        s.setCreadoEn(rs.getString("creado_en"));
        return s;
    }
}
