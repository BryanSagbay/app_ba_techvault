package com.sysops.modules.comandos;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.Comando;
import org.jdbi.v3.core.Jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ComandoDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    public List<Comando> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM comandos ORDER BY categoria, nombre")
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public List<Comando> search(String query) {
        String q = "%" + query + "%";
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM comandos
                WHERE nombre LIKE :q OR comando LIKE :q OR descripcion LIKE :q
                   OR categoria LIKE :q OR etiquetas LIKE :q
                ORDER BY categoria, nombre
            """)
             .bind("q", q)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public int insert(Comando c) {
        return jdbi.withHandle(h ->
            h.createUpdate("""
                INSERT INTO comandos (nombre, comando, descripcion, categoria, sistema_op, etiquetas)
                VALUES (:nombre, :comando, :descripcion, :categoria, :sistemaOp, :etiquetas)
            """)
             .bind("nombre",      c.getNombre())
             .bind("comando",     c.getComando())
             .bind("descripcion", c.getDescripcion())
             .bind("categoria",   c.getCategoria())
             .bind("sistemaOp",   c.getSistemaOp())
             .bind("etiquetas",   c.getEtiquetas())
             .executeAndReturnGeneratedKeys("id")
             .mapTo(Integer.class).one()
        );
    }

    public void update(Comando c) {
        jdbi.withHandle(h ->
            h.createUpdate("""
                UPDATE comandos SET
                  nombre=:nombre, comando=:comando, descripcion=:descripcion,
                  categoria=:categoria, sistema_op=:sistemaOp, etiquetas=:etiquetas
                WHERE id=:id
            """)
             .bind("id",          c.getId())
             .bind("nombre",      c.getNombre())
             .bind("comando",     c.getComando())
             .bind("descripcion", c.getDescripcion())
             .bind("categoria",   c.getCategoria())
             .bind("sistemaOp",   c.getSistemaOp())
             .bind("etiquetas",   c.getEtiquetas())
             .execute()
        );
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM comandos WHERE id = :id")
             .bind("id", id).execute()
        );
    }

    private Comando mapRow(ResultSet rs) throws SQLException {
        Comando c = new Comando();
        c.setId(rs.getInt("id"));
        c.setNombre(rs.getString("nombre"));
        c.setComando(rs.getString("comando"));
        c.setDescripcion(rs.getString("descripcion"));
        c.setCategoria(rs.getString("categoria"));
        c.setSistemaOp(rs.getString("sistema_op"));
        c.setEtiquetas(rs.getString("etiquetas"));
        c.setCreadoEn(rs.getString("creado_en"));
        return c;
    }
}
