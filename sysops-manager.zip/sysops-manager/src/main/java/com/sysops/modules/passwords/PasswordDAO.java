package com.sysops.modules.passwords;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.PasswordEntry;
import com.sysops.utils.CryptoUtil;
import org.jdbi.v3.core.Jdbi;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class PasswordDAO {

    private final Jdbi jdbi = DatabaseConfig.getJdbi();

    /** Obtiene todas las entradas SIN desencriptar (passwords ocultos) */
    public List<PasswordEntry> findAll() {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM passwords ORDER BY categoria, nombre")
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    /** Obtiene y desencripta la contraseña con la master password */
    public Optional<PasswordEntry> findByIdDecrypted(int id, char[] masterPassword) {
        return jdbi.withHandle(h ->
            h.createQuery("SELECT * FROM passwords WHERE id = :id")
             .bind("id", id)
             .map((rs, ctx) -> mapRow(rs))
             .findFirst()
        ).map(entry -> {
            try {
                String plain = CryptoUtil.decrypt(entry.getPasswordEnc(), masterPassword);
                entry.setPasswordPlain(plain);
                return entry;
            } catch (Exception e) {
                throw new RuntimeException("Contraseña maestra incorrecta", e);
            }
        });
    }

    public List<PasswordEntry> search(String query) {
        String q = "%" + query + "%";
        return jdbi.withHandle(h ->
            h.createQuery("""
                SELECT * FROM passwords
                WHERE nombre LIKE :q OR usuario LIKE :q OR categoria LIKE :q OR url LIKE :q
                ORDER BY categoria, nombre
            """)
             .bind("q", q)
             .map((rs, ctx) -> mapRow(rs)).list()
        );
    }

    public int insert(PasswordEntry p, char[] masterPassword) {
        try {
            String encrypted = CryptoUtil.encrypt(p.getPasswordPlain(), masterPassword);
            return jdbi.withHandle(h ->
                h.createUpdate("""
                    INSERT INTO passwords
                      (nombre, usuario, password_enc, url, categoria, notas)
                    VALUES
                      (:nombre, :usuario, :enc, :url, :categoria, :notas)
                """)
                 .bind("nombre",    p.getNombre())
                 .bind("usuario",   p.getUsuario())
                 .bind("enc",       encrypted)
                 .bind("url",       p.getUrl())
                 .bind("categoria", p.getCategoria())
                 .bind("notas",     p.getNotas())
                 .executeAndReturnGeneratedKeys("id")
                 .mapTo(Integer.class).one()
            );
        } catch (Exception e) {
            throw new RuntimeException("Error encriptando contraseña", e);
        }
    }

    public void update(PasswordEntry p, char[] masterPassword) {
        try {
            String encrypted = CryptoUtil.encrypt(p.getPasswordPlain(), masterPassword);
            jdbi.withHandle(h ->
                h.createUpdate("""
                    UPDATE passwords SET
                      nombre=:nombre, usuario=:usuario, password_enc=:enc,
                      url=:url, categoria=:categoria, notas=:notas,
                      actualizado_en=datetime('now','localtime')
                    WHERE id=:id
                """)
                 .bind("id",        p.getId())
                 .bind("nombre",    p.getNombre())
                 .bind("usuario",   p.getUsuario())
                 .bind("enc",       encrypted)
                 .bind("url",       p.getUrl())
                 .bind("categoria", p.getCategoria())
                 .bind("notas",     p.getNotas())
                 .execute()
            );
        } catch (Exception e) {
            throw new RuntimeException("Error encriptando contraseña", e);
        }
    }

    public void delete(int id) {
        jdbi.withHandle(h ->
            h.createUpdate("DELETE FROM passwords WHERE id = :id")
             .bind("id", id).execute()
        );
    }

    private PasswordEntry mapRow(ResultSet rs) throws SQLException {
        PasswordEntry p = new PasswordEntry();
        p.setId(rs.getInt("id"));
        p.setNombre(rs.getString("nombre"));
        p.setUsuario(rs.getString("usuario"));
        p.setPasswordEnc(rs.getString("password_enc"));
        p.setUrl(rs.getString("url"));
        p.setCategoria(rs.getString("categoria"));
        p.setNotas(rs.getString("notas"));
        p.setCreadoEn(rs.getString("creado_en"));
        p.setActualizadoEn(rs.getString("actualizado_en"));
        return p;
    }
}
