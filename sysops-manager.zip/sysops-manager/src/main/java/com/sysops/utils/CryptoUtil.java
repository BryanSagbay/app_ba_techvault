package com.sysops.utils;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

/**
 * Utilidad de encriptación AES-256-GCM para el gestor de contraseñas.
 * No requiere dependencias externas — usa javax.crypto nativo de Java.
 */
public class CryptoUtil {

    private static final String ALGORITHM  = "AES/GCM/NoPadding";
    private static final int    KEY_LENGTH  = 256;
    private static final int    TAG_LENGTH  = 128;
    private static final int    IV_LENGTH   = 12;
    private static final int    SALT_LENGTH = 16;
    private static final int    ITERATIONS  = 310_000;

    // ── Derivar clave AES desde contraseña master ──────────────────────────
    private static SecretKey deriveKey(char[] masterPassword, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(masterPassword, salt, ITERATIONS, KEY_LENGTH);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }

    // ── Encriptar ──────────────────────────────────────────────────────────
    /**
     * Encripta un texto plano con AES-256-GCM.
     * @param plainText      texto a encriptar
     * @param masterPassword contraseña maestra
     * @return  Base64(salt + iv + ciphertext)
     */
    public static String encrypt(String plainText, char[] masterPassword)
            throws GeneralSecurityException {
        byte[] salt = new byte[SALT_LENGTH];
        byte[] iv   = new byte[IV_LENGTH];
        new SecureRandom().nextBytes(salt);
        new SecureRandom().nextBytes(iv);

        SecretKey key = deriveKey(masterPassword, salt);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key,
                new GCMParameterSpec(TAG_LENGTH, iv));

        byte[] cipherText = cipher.doFinal(plainText.getBytes());

        // Concatenar: salt(16) + iv(12) + ciphertext
        byte[] combined = new byte[SALT_LENGTH + IV_LENGTH + cipherText.length];
        System.arraycopy(salt,       0, combined, 0,                          SALT_LENGTH);
        System.arraycopy(iv,         0, combined, SALT_LENGTH,                IV_LENGTH);
        System.arraycopy(cipherText, 0, combined, SALT_LENGTH + IV_LENGTH,    cipherText.length);

        return Base64.getEncoder().encodeToString(combined);
    }

    // ── Desencriptar ───────────────────────────────────────────────────────
    /**
     * Desencripta un texto previamente encriptado con {@link #encrypt}.
     * @param encryptedData  Base64(salt + iv + ciphertext)
     * @param masterPassword contraseña maestra
     * @return texto plano
     */
    public static String decrypt(String encryptedData, char[] masterPassword)
            throws GeneralSecurityException {
        byte[] combined = Base64.getDecoder().decode(encryptedData);

        byte[] salt       = new byte[SALT_LENGTH];
        byte[] iv         = new byte[IV_LENGTH];
        byte[] cipherText = new byte[combined.length - SALT_LENGTH - IV_LENGTH];

        System.arraycopy(combined, 0,                       salt,       0, SALT_LENGTH);
        System.arraycopy(combined, SALT_LENGTH,             iv,         0, IV_LENGTH);
        System.arraycopy(combined, SALT_LENGTH + IV_LENGTH, cipherText, 0, cipherText.length);

        SecretKey key = deriveKey(masterPassword, salt);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key,
                new GCMParameterSpec(TAG_LENGTH, iv));

        return new String(cipher.doFinal(cipherText));
    }

    // ── Hash master password para verificación ─────────────────────────────
    public static String hashMasterPassword(char[] password) throws GeneralSecurityException {
        byte[] salt = "SYSOPS_FIXED_SALT".getBytes();
        try {
            return encrypt(new String(password) + "_VERIFY", password);
        } catch (GeneralSecurityException e) {
            throw e;
        }
    }

    public static boolean verifyMasterPassword(char[] password, String storedHash) {
        try {
            String decrypted = decrypt(storedHash, password);
            return decrypted.endsWith("_VERIFY");
        } catch (Exception e) {
            return false;
        }
    }
}
