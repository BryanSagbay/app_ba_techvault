package com.sysops.controllers;

import com.sysops.models.Comando;
import com.sysops.modules.comandos.ComandoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class ComandoController implements Initializable {

    @FXML private TextField txtBuscar;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private TableView<Comando> tabla;
    @FXML private TableColumn<Comando,String> colNombre, colComando, colCategoria, colSistemaOp;
    @FXML private TableColumn<Comando,Void>   colAcciones;
    @FXML private TitledPane paneForm;

    @FXML private TextField  fNombre, fEtiquetas;
    @FXML private TextArea   fComando, fDescripcion;
    @FXML private ComboBox<String> fCategoria, fSistemaOp;

    private final ComandoDAO dao = new ComandoDAO();
    private final ObservableList<Comando> items = FXCollections.observableArrayList();
    private Comando editando = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colComando.setCellValueFactory(new PropertyValueFactory<>("comando"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colSistemaOp.setCellValueFactory(new PropertyValueFactory<>("sistemaOp"));

        // Estilo monospace para columna comando
        colComando.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle("-fx-font-family: 'Courier New', monospace; -fx-text-fill: #00ff88;");
            }
        });

        colAcciones.setCellFactory(col -> new TableCell<>() {
            final Button btnCopy = new Button("📋");
            final Button btnEdit = new Button("✏");
            final Button btnDel  = new Button("🗑");
            final HBox box = new HBox(4, btnCopy, btnEdit, btnDel);
            {
                btnCopy.setStyle("-fx-background-color: #37474f; -fx-text-fill: white; -fx-cursor: hand;");
                btnEdit.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: white; -fx-cursor: hand;");
                btnDel.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-cursor: hand;");
                btnCopy.setOnAction(e -> {
                    Comando c = getTableRow().getItem();
                    if (c == null) return;
                    ClipboardContent cc = new ClipboardContent();
                    cc.putString(c.getComando());
                    Clipboard.getSystemClipboard().setContent(cc);
                    btnCopy.setText("✅");
                    new java.util.Timer(true).schedule(new java.util.TimerTask() {
                        @Override public void run() {
                            javafx.application.Platform.runLater(() -> btnCopy.setText("📋"));
                        }
                    }, 1500);
                });
                btnEdit.setOnAction(e -> editarItem(getTableRow().getItem()));
                btnDel.setOnAction(e -> eliminarItem(getTableRow().getItem()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        var cats = FXCollections.observableArrayList(
                "Linux", "Windows", "Docker", "Git", "SQL", "Red", "Java", "Otro");
        cmbCategoria.setItems(FXCollections.observableArrayList("TODAS"));
        cmbCategoria.getItems().addAll(cats);
        cmbCategoria.setValue("TODAS");
        cmbCategoria.setOnAction(e -> loadAll());

        fCategoria.setItems(cats);
        fSistemaOp.setItems(FXCollections.observableArrayList("Linux","Windows","MacOS","Cross-platform"));

        tabla.setItems(items);
        loadAll();
    }

    private void loadAll() {
        var all = dao.findAll();
        String cat = cmbCategoria.getValue();
        if (!"TODAS".equals(cat)) all = all.stream().filter(c -> cat.equals(c.getCategoria())).toList();
        items.setAll(all);
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) loadAll();
        else items.setAll(dao.search(q));
    }

    @FXML private void onNuevo() {
        editando = null; clearForm();
        paneForm.setExpanded(true);
        paneForm.setText("Nuevo Comando");
    }

    private void editarItem(Comando c) {
        if (c == null) return;
        editando = c;
        fNombre.setText(c.getNombre()); fComando.setText(c.getComando());
        fCategoria.setValue(c.getCategoria()); fSistemaOp.setValue(c.getSistemaOp());
        fDescripcion.setText(c.getDescripcion()); fEtiquetas.setText(c.getEtiquetas());
        paneForm.setExpanded(true);
        paneForm.setText("Editar — " + c.getNombre());
    }

    private void eliminarItem(Comando c) {
        if (c == null) return;
        new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar \"" + c.getNombre() + "\"?",
                  ButtonType.YES, ButtonType.NO)
            .showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) { dao.delete(c.getId()); loadAll(); }
            });
    }

    @FXML private void onGuardar() {
        if (fNombre.getText().isBlank() || fComando.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "Nombre y Comando son obligatorios").showAndWait();
            return;
        }
        Comando c = editando != null ? editando : new Comando();
        c.setNombre(fNombre.getText().trim()); c.setComando(fComando.getText().trim());
        c.setCategoria(fCategoria.getValue()); c.setSistemaOp(fSistemaOp.getValue());
        c.setDescripcion(fDescripcion.getText().trim()); c.setEtiquetas(fEtiquetas.getText().trim());

        if (editando == null) dao.insert(c); else dao.update(c);
        loadAll();
        paneForm.setExpanded(false);
        clearForm();
    }

    @FXML private void onCancelar() { paneForm.setExpanded(false); clearForm(); }

    private void clearForm() {
        fNombre.clear(); fComando.clear(); fDescripcion.clear(); fEtiquetas.clear();
        fCategoria.setValue(null); fSistemaOp.setValue(null);
        editando = null;
    }
}
