package com.sysops.controllers;

import com.sysops.models.Correctivo;
import com.sysops.modules.correctivos.CorrectivoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

public class CorrectivoController implements Initializable {

    @FXML private TextField  txtBuscar;
    @FXML private ComboBox<String> cmbFiltroEstado;
    @FXML private TableView<Correctivo> tabla;
    @FXML private TableColumn<Correctivo,String> colTicket, colTitulo, colServidor,
                                                  colAmbiente, colEstado, colPrioridad,
                                                  colFecha;
    @FXML private TableColumn<Correctivo,Void>   colAcciones;
    @FXML private TitledPane paneForm;

    // Formulario
    @FXML private TextField  fTicket, fServidor, fTitulo, fTiempo, fEtiquetas;
    @FXML private TextArea   fDescripcion, fSolucion;
    @FXML private ComboBox<String> fAmbiente, fEstado, fPrioridad;

    private final CorrectivoDAO dao = new CorrectivoDAO();
    private final ObservableList<Correctivo> items = FXCollections.observableArrayList();
    private Correctivo editando = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupColumns();
        setupCombos();
        tabla.setItems(items);
        loadAll();
    }

    private void setupColumns() {
        colTicket.setCellValueFactory(new PropertyValueFactory<>("ticket"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colServidor.setCellValueFactory(new PropertyValueFactory<>("servidor"));
        colAmbiente.setCellValueFactory(new PropertyValueFactory<>("ambiente"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("creadoEn"));

        // Celda acciones con botones Editar / Borrar
        colAcciones.setCellFactory(col -> new TableCell<>() {
            final Button btnEdit = new Button("✏");
            final Button btnDel  = new Button("🗑");
            final HBox box = new HBox(6, btnEdit, btnDel);
            {
                btnEdit.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: white; -fx-cursor: hand;");
                btnDel.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-cursor: hand;");
                btnEdit.setOnAction(e -> editarItem(getTableRow().getItem()));
                btnDel.setOnAction(e -> eliminarItem(getTableRow().getItem()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        // Color por estado
        colEstado.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "ABIERTO"    -> "-fx-text-fill: #ff6b6b; -fx-font-weight: bold;";
                    case "EN_PROCESO" -> "-fx-text-fill: #ffd93d; -fx-font-weight: bold;";
                    case "RESUELTO"   -> "-fx-text-fill: #6bcb77; -fx-font-weight: bold;";
                    case "CERRADO"    -> "-fx-text-fill: #888;";
                    default           -> "";
                });
            }
        });

        colPrioridad.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "CRITICA" -> "-fx-text-fill: #ff0000; -fx-font-weight: bold;";
                    case "ALTA"    -> "-fx-text-fill: #ff6b6b;";
                    case "MEDIA"   -> "-fx-text-fill: #ffd93d;";
                    default        -> "-fx-text-fill: #88cc88;";
                });
            }
        });
    }

    private void setupCombos() {
        cmbFiltroEstado.setItems(FXCollections.observableArrayList(
                "TODOS", "ABIERTO", "EN_PROCESO", "RESUELTO", "CERRADO"));
        cmbFiltroEstado.setValue("TODOS");
        cmbFiltroEstado.setOnAction(e -> onFiltrar());

        fEstado.setItems(FXCollections.observableArrayList(
                "ABIERTO", "EN_PROCESO", "RESUELTO", "CERRADO"));
        fPrioridad.setItems(FXCollections.observableArrayList(
                "BAJA", "MEDIA", "ALTA", "CRITICA"));
        fAmbiente.setItems(FXCollections.observableArrayList(
                "PRD", "QA", "DEV", "HOM", "OTRO"));

        fEstado.setValue("ABIERTO");
        fPrioridad.setValue("MEDIA");
    }

    private void loadAll() {
        items.setAll(dao.findAll());
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) loadAll();
        else items.setAll(dao.search(q));
    }

    private void onFiltrar() {
        String estado = cmbFiltroEstado.getValue();
        if ("TODOS".equals(estado)) loadAll();
        else items.setAll(dao.findByEstado(estado));
    }

    @FXML private void onNuevo() {
        editando = null;
        clearForm();
        paneForm.setExpanded(true);
        paneForm.setText("Nuevo Correctivo");
    }

    private void editarItem(Correctivo c) {
        if (c == null) return;
        editando = c;
        fTicket.setText(c.getTicket());
        fTitulo.setText(c.getTitulo());
        fServidor.setText(c.getServidor());
        fAmbiente.setValue(c.getAmbiente());
        fEstado.setValue(c.getEstado());
        fPrioridad.setValue(c.getPrioridad());
        fDescripcion.setText(c.getDescripcion());
        fSolucion.setText(c.getSolucion());
        fTiempo.setText(c.getTiempoResolucion());
        fEtiquetas.setText(c.getEtiquetas());
        paneForm.setExpanded(true);
        paneForm.setText("Editar Correctivo — " + c.getTitulo());
    }

    private void eliminarItem(Correctivo c) {
        if (c == null) return;
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar el correctivo \"" + c.getTitulo() + "\"?",
                ButtonType.YES, ButtonType.NO);
        alert.setHeaderText("Confirmar eliminación");
        alert.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                dao.delete(c.getId());
                loadAll();
            }
        });
    }

    @FXML private void onGuardar() {
        if (fTitulo.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "El título es obligatorio").showAndWait();
            return;
        }
        Correctivo c = editando != null ? editando : new Correctivo();
        c.setTicket(fTicket.getText().trim());
        c.setTitulo(fTitulo.getText().trim());
        c.setServidor(fServidor.getText().trim());
        c.setAmbiente(fAmbiente.getValue());
        c.setEstado(fEstado.getValue());
        c.setPrioridad(fPrioridad.getValue());
        c.setDescripcion(fDescripcion.getText().trim());
        c.setSolucion(fSolucion.getText().trim());
        c.setTiempoResolucion(fTiempo.getText().trim());
        c.setEtiquetas(fEtiquetas.getText().trim());

        if (editando == null) {
            c.setFechaInicio(LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
            dao.insert(c);
        } else {
            dao.update(c);
        }
        loadAll();
        paneForm.setExpanded(false);
        clearForm();
    }

    @FXML private void onCancelar() {
        paneForm.setExpanded(false);
        clearForm();
    }

    private void clearForm() {
        fTicket.clear(); fTitulo.clear(); fServidor.clear();
        fDescripcion.clear(); fSolucion.clear();
        fTiempo.clear(); fEtiquetas.clear();
        fEstado.setValue("ABIERTO");
        fPrioridad.setValue("MEDIA");
        fAmbiente.setValue(null);
    }
}
