package com.sysops.controllers;

import com.sysops.App;
import com.sysops.config.DatabaseConfig;
import com.sysops.modules.correctivos.CorrectivoDAO;
import com.sysops.modules.tareas.TareaDAO;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML private BorderPane rootPane;
    @FXML private StackPane  contentArea;
    @FXML private Label      lblModulo;
    @FXML private Label      lblVersion;
    @FXML private Label      lblDbPath;
    @FXML private VBox       navBar;

    // Botones de navegación
    @FXML private Button btnDashboard;
    @FXML private Button btnCorrectivos;
    @FXML private Button btnServidores;
    @FXML private Button btnPasswords;
    @FXML private Button btnTareas;
    @FXML private Button btnNotas;
    @FXML private Button btnComandos;

    private Button activeBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblVersion.setText("v" + App.VERSION);
        lblDbPath.setText(App.DATA_DIR.toString());
    }

    public void initializeApp(Stage stage) {
        loadDashboard();
    }

    @FXML
    private void loadDashboard() {
        setActive(btnDashboard, "Dashboard");
        loadView("/fxml/DashboardView.fxml");
    }

    @FXML
    private void loadCorrectivos() {
        setActive(btnCorrectivos, "Correctivos");
        loadView("/fxml/CorrectivoView.fxml");
    }

    @FXML
    private void loadServidores() {
        setActive(btnServidores, "Servidores & IPs");
        loadView("/fxml/ServidorView.fxml");
    }

    @FXML
    private void loadPasswords() {
        setActive(btnPasswords, "Gestor de Contraseñas");
        loadView("/fxml/PasswordView.fxml");
    }

    @FXML
    private void loadTareas() {
        setActive(btnTareas, "Tareas");
        loadView("/fxml/TareaView.fxml");
    }

    @FXML
    private void loadNotas() {
        setActive(btnNotas, "Notas");
        loadView("/fxml/NotaView.fxml");
    }

    @FXML
    private void loadComandos() {
        setActive(btnComandos, "Comandos & Manuales");
        loadView("/fxml/ComandoView.fxml");
    }

    private void loadView(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Node view = loader.load();
            contentArea.getChildren().setAll(view);
        } catch (IOException e) {
            e.printStackTrace();
            lblModulo.setText("Error cargando módulo");
        }
    }

    private void setActive(Button btn, String nombre) {
        if (activeBtn != null) activeBtn.getStyleClass().remove("nav-active");
        btn.getStyleClass().add("nav-active");
        activeBtn = btn;
        lblModulo.setText(nombre);
    }

    @FXML
    private void handleExit() {
        Platform.exit();
    }
}
