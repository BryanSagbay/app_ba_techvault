package com.sysops.controllers;

import com.sysops.models.Correctivo;
import com.sysops.models.Tarea;
import com.sysops.modules.comandos.ComandoDAO;
import com.sysops.modules.correctivos.CorrectivoDAO;
import com.sysops.modules.servidores.ServidorDAO;
import com.sysops.modules.tareas.TareaDAO;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class DashboardController implements Initializable {

    @FXML private Label lblFecha;
    @FXML private Label lblCorrectivosAbiertos;
    @FXML private Label lblTareasPendientes;
    @FXML private Label lblServidores;
    @FXML private Label lblComandos;

    @FXML private TableView<Correctivo> tblCorrectivos;
    @FXML private TableColumn<Correctivo, String> colTicket, colTitulo, colEstado, colPrioridad, colFecha;

    @FXML private TableView<Tarea> tblTareas;
    @FXML private TableColumn<Tarea, String> colTTitulo, colTPrioridad, colTEstado, colTFecha;

    private final CorrectivoDAO correctivoDAO = new CorrectivoDAO();
    private final TareaDAO      tareaDAO      = new TareaDAO();
    private final ServidorDAO   servidorDAO   = new ServidorDAO();
    private final ComandoDAO    comandoDAO    = new ComandoDAO();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblFecha.setText(LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM yyyy  HH:mm")));

        setupTables();
        loadData();
    }

    private void setupTables() {
        colTicket.setCellValueFactory(new PropertyValueFactory<>("ticket"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("creadoEn"));

        colTTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colTPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad"));
        colTEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colTFecha.setCellValueFactory(new PropertyValueFactory<>("fechaLimite"));

        // Colores por estado en correctivos
        colEstado.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "ABIERTO"    -> "-fx-text-fill: #ff6b6b; -fx-font-weight: bold;";
                    case "EN_PROCESO" -> "-fx-text-fill: #ffd93d; -fx-font-weight: bold;";
                    case "RESUELTO"   -> "-fx-text-fill: #6bcb77; -fx-font-weight: bold;";
                    default           -> "-fx-text-fill: #aaa;";
                });
            }
        });

        // Colores por prioridad
        colPrioridad.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "CRITICA" -> "-fx-text-fill: #ff0000; -fx-font-weight: bold;";
                    case "ALTA"    -> "-fx-text-fill: #ff6b6b;";
                    case "MEDIA"   -> "-fx-text-fill: #ffd93d;";
                    default        -> "-fx-text-fill: #aaa;";
                });
            }
        });
    }

    private void loadData() {
        List<Correctivo> correctivos = correctivoDAO.findAll();
        List<Tarea>      tareas      = tareaDAO.findPendientes();

        long abiertos = correctivos.stream()
                .filter(c -> "ABIERTO".equals(c.getEstado()) || "EN_PROCESO".equals(c.getEstado()))
                .count();

        lblCorrectivosAbiertos.setText(String.valueOf(abiertos));
        lblTareasPendientes.setText(String.valueOf(tareas.size()));
        lblServidores.setText(String.valueOf(servidorDAO.findAll().size()));
        lblComandos.setText(String.valueOf(comandoDAO.findAll().size()));

        tblCorrectivos.setItems(FXCollections.observableArrayList(
                correctivos.stream().limit(10).collect(Collectors.toList())
        ));
        tblTareas.setItems(FXCollections.observableArrayList(
                tareas.stream().limit(10).collect(Collectors.toList())
        ));
    }
}
