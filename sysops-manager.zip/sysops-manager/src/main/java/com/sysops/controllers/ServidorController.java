package com.sysops.controllers;

import com.sysops.models.Servidor;
import com.sysops.modules.servidores.ServidorDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.util.ResourceBundle;

public class ServidorController implements Initializable {

    @FXML private TextField txtBuscar;
    @FXML private ComboBox<String> cmbAmbiente;
    @FXML private TableView<Servidor> tabla;
    @FXML private TableColumn<Servidor,String> colNombre, colIp, colAmbiente, colTipo,
                                                colSo, colDescripcion;
    @FXML private TableColumn<Servidor,Integer> colPuerto;
    @FXML private TableColumn<Servidor,Boolean> colActivo;
    @FXML private TableColumn<Servidor,Void>    colAcciones;
    @FXML private TitledPane paneForm;

    @FXML private TextField fNombre, fIp, fPuerto, fSo, fUsuario;
    @FXML private ComboBox<String> fAmbiente, fTipo;
    @FXML private TextArea fDescripcion, fNotas;
    @FXML private CheckBox fActivo;

    private final ServidorDAO dao = new ServidorDAO();
    private final ObservableList<Servidor> items = FXCollections.observableArrayList();
    private Servidor editando = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colIp.setCellValueFactory(new PropertyValueFactory<>("ip"));
        colAmbiente.setCellValueFactory(new PropertyValueFactory<>("ambiente"));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colPuerto.setCellValueFactory(new PropertyValueFactory<>("puerto"));
        colSo.setCellValueFactory(new PropertyValueFactory<>("so"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));

        colAmbiente.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "PRD" -> "-fx-text-fill: #ff6b6b; -fx-font-weight: bold;";
                    case "QA"  -> "-fx-text-fill: #ffd93d;";
                    case "DEV" -> "-fx-text-fill: #6bcb77;";
                    default    -> "-fx-text-fill: #aaa;";
                });
            }
        });

        colAcciones.setCellFactory(col -> new TableCell<>() {
            final Button btnEdit = new Button("✏");
            final Button btnDel  = new Button("🗑");
            final HBox box = new HBox(6, btnEdit, btnDel);
            {
                btnEdit.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: white; -fx-cursor: hand;");
                btnDel.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-cursor: hand;");
                btnEdit.setOnAction(e -> editarItem(getTableRow().getItem()));
                btnDel.setOnAction(e -> eliminarItem(getTableRow().getItem()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        cmbAmbiente.setItems(FXCollections.observableArrayList("TODOS","PRD","QA","DEV","HOM"));
        cmbAmbiente.setValue("TODOS");
        cmbAmbiente.setOnAction(e -> {
            String amb = cmbAmbiente.getValue();
            if ("TODOS".equals(amb)) items.setAll(dao.findAll());
            else items.setAll(dao.findByAmbiente(amb));
        });

        fAmbiente.setItems(FXCollections.observableArrayList("PRD","QA","DEV","HOM","OTRO"));
        fTipo.setItems(FXCollections.observableArrayList("APP","BD","WEB","PROXY","CACHE","LDAP","OTRO"));

        tabla.setItems(items);
        items.setAll(dao.findAll());
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) items.setAll(dao.findAll());
        else items.setAll(dao.search(q));
    }

    @FXML private void onNuevo() {
        editando = null; clearForm();
        paneForm.setExpanded(true);
        paneForm.setText("Nuevo Servidor");
    }

    private void editarItem(Servidor s) {
        if (s == null) return;
        editando = s;
        fNombre.setText(s.getNombre()); fIp.setText(s.getIp());
        fAmbiente.setValue(s.getAmbiente()); fTipo.setValue(s.getTipo());
        fPuerto.setText(String.valueOf(s.getPuerto())); fSo.setText(s.getSo());
        fUsuario.setText(s.getUsuario()); fDescripcion.setText(s.getDescripcion());
        fNotas.setText(s.getNotas()); fActivo.setSelected(s.isActivo());
        paneForm.setExpanded(true);
        paneForm.setText("Editar — " + s.getNombre());
    }

    private void eliminarItem(Servidor s) {
        if (s == null) return;
        new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar \"" + s.getNombre() + "\"?",
                  ButtonType.YES, ButtonType.NO)
            .showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) { dao.delete(s.getId()); items.setAll(dao.findAll()); }
            });
    }

    @FXML private void onGuardar() {
        if (fNombre.getText().isBlank() || fIp.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "Nombre e IP son obligatorios").showAndWait();
            return;
        }
        Servidor s = editando != null ? editando : new Servidor();
        s.setNombre(fNombre.getText().trim()); s.setIp(fIp.getText().trim());
        s.setAmbiente(fAmbiente.getValue()); s.setTipo(fTipo.getValue());
        try { s.setPuerto(Integer.parseInt(fPuerto.getText().trim())); } catch (Exception e) { s.setPuerto(0); }
        s.setSo(fSo.getText().trim()); s.setUsuario(fUsuario.getText().trim());
        s.setDescripcion(fDescripcion.getText().trim());
        s.setNotas(fNotas.getText().trim()); s.setActivo(fActivo.isSelected());

        if (editando == null) dao.insert(s); else dao.update(s);
        items.setAll(dao.findAll());
        paneForm.setExpanded(false);
        clearForm();
    }

    @FXML private void onCancelar() { paneForm.setExpanded(false); clearForm(); }

    private void clearForm() {
        fNombre.clear(); fIp.clear(); fPuerto.clear(); fSo.clear();
        fUsuario.clear(); fDescripcion.clear(); fNotas.clear();
        fAmbiente.setValue(null); fTipo.setValue(null);
        fActivo.setSelected(true); editando = null;
    }
}
