package com.sysops.controllers;

import com.sysops.models.Tarea;
import com.sysops.modules.tareas.TareaDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class TareaController implements Initializable {

    @FXML private TextField txtBuscar;
    @FXML private ComboBox<String> cmbEstado, cmbPrioridad;
    @FXML private TableView<Tarea> tabla;
    @FXML private TableColumn<Tarea,String> colTitulo, colCategoria, colPrioridad, colEstado, colFechaLimite;
    @FXML private TableColumn<Tarea,Void>   colAcciones;
    @FXML private TitledPane paneForm;

    @FXML private TextField  fTitulo, fCategoria, fFechaLimite;
    @FXML private ComboBox<String> fPrioridad, fEstado;
    @FXML private TextArea   fDescripcion;

    private final TareaDAO dao = new TareaDAO();
    private final ObservableList<Tarea> items = FXCollections.observableArrayList();
    private Tarea editando = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colFechaLimite.setCellValueFactory(new PropertyValueFactory<>("fechaLimite"));

        colPrioridad.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "URGENTE" -> "-fx-text-fill: #ff0000; -fx-font-weight: bold;";
                    case "ALTA"    -> "-fx-text-fill: #ff6b6b;";
                    case "MEDIA"   -> "-fx-text-fill: #ffd93d;";
                    default        -> "-fx-text-fill: #88cc88;";
                });
            }
        });

        colEstado.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "PENDIENTE"   -> "-fx-text-fill: #aaa;";
                    case "EN_PROCESO"  -> "-fx-text-fill: #ffd93d; -fx-font-weight: bold;";
                    case "COMPLETADA"  -> "-fx-text-fill: #6bcb77;";
                    case "CANCELADA"   -> "-fx-text-fill: #555; -fx-strikethrough: true;";
                    default            -> "";
                });
            }
        });

        colAcciones.setCellFactory(col -> new TableCell<>() {
            final Button btnComplete = new Button("✅");
            final Button btnEdit     = new Button("✏");
            final Button btnDel      = new Button("🗑");
            final HBox box = new HBox(4, btnComplete, btnEdit, btnDel);
            {
                btnComplete.setStyle("-fx-background-color: #2e7d32; -fx-text-fill: white; -fx-cursor: hand;");
                btnEdit.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: white; -fx-cursor: hand;");
                btnDel.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-cursor: hand;");
                btnComplete.setOnAction(e -> completarTarea(getTableRow().getItem()));
                btnEdit.setOnAction(e -> editarItem(getTableRow().getItem()));
                btnDel.setOnAction(e -> eliminarItem(getTableRow().getItem()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        cmbEstado.setItems(FXCollections.observableArrayList("TODOS","PENDIENTE","EN_PROCESO","COMPLETADA","CANCELADA"));
        cmbEstado.setValue("TODOS");
        cmbEstado.setOnAction(e -> loadAll());

        cmbPrioridad.setItems(FXCollections.observableArrayList("TODAS","BAJA","MEDIA","ALTA","URGENTE"));
        cmbPrioridad.setValue("TODAS");
        cmbPrioridad.setOnAction(e -> loadAll());

        fEstado.setItems(FXCollections.observableArrayList("PENDIENTE","EN_PROCESO","COMPLETADA","CANCELADA"));
        fPrioridad.setItems(FXCollections.observableArrayList("BAJA","MEDIA","ALTA","URGENTE"));
        fEstado.setValue("PENDIENTE"); fPrioridad.setValue("MEDIA");

        tabla.setItems(items);
        loadAll();
    }

    private void loadAll() {
        var all = dao.findAll();
        String est = cmbEstado.getValue();
        String pri = cmbPrioridad.getValue();
        if (!"TODOS".equals(est))   all = all.stream().filter(t -> est.equals(t.getEstado())).toList();
        if (!"TODAS".equals(pri))   all = all.stream().filter(t -> pri.equals(t.getPrioridad())).toList();
        items.setAll(all);
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim().toLowerCase();
        if (q.isEmpty()) { loadAll(); return; }
        items.setAll(dao.findAll().stream()
                .filter(t -> t.getTitulo().toLowerCase().contains(q))
                .toList());
    }

    @FXML private void onNuevo() {
        editando = null; clearForm();
        paneForm.setExpanded(true);
        paneForm.setText("Nueva Tarea");
    }

    private void completarTarea(Tarea t) {
        if (t == null) return;
        t.setEstado("COMPLETADA");
        t.setCompletadaEn(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
        dao.update(t);
        loadAll();
    }

    private void editarItem(Tarea t) {
        if (t == null) return;
        editando = t;
        fTitulo.setText(t.getTitulo());
        fCategoria.setText(t.getCategoria());
        fPrioridad.setValue(t.getPrioridad());
        fEstado.setValue(t.getEstado());
        fFechaLimite.setText(t.getFechaLimite());
        fDescripcion.setText(t.getDescripcion());
        paneForm.setExpanded(true);
        paneForm.setText("Editar Tarea");
    }

    private void eliminarItem(Tarea t) {
        if (t == null) return;
        new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar \"" + t.getTitulo() + "\"?",
                  ButtonType.YES, ButtonType.NO)
            .showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) { dao.delete(t.getId()); loadAll(); }
            });
    }

    @FXML private void onGuardar() {
        if (fTitulo.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "El título es obligatorio").showAndWait();
            return;
        }
        Tarea t = editando != null ? editando : new Tarea();
        t.setTitulo(fTitulo.getText().trim());
        t.setCategoria(fCategoria.getText().trim());
        t.setPrioridad(fPrioridad.getValue());
        t.setEstado(fEstado.getValue());
        t.setFechaLimite(fFechaLimite.getText().trim());
        t.setDescripcion(fDescripcion.getText().trim());

        if (editando == null) dao.insert(t); else dao.update(t);
        loadAll();
        paneForm.setExpanded(false);
        clearForm();
    }

    @FXML private void onCancelar() { paneForm.setExpanded(false); clearForm(); }

    private void clearForm() {
        fTitulo.clear(); fCategoria.clear(); fFechaLimite.clear(); fDescripcion.clear();
        fEstado.setValue("PENDIENTE"); fPrioridad.setValue("MEDIA");
        editando = null;
    }
}
