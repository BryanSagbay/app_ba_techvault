package com.sysops.controllers;

import com.sysops.models.Nota;
import com.sysops.modules.notas.NotaDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class NotaController implements Initializable {

    @FXML private TextField txtBuscar;
    @FXML private ListView<Nota> listNotas;
    @FXML private TextField fTitulo, fEtiquetas;
    @FXML private TextArea  fContenido;
    @FXML private CheckBox  fFijada;

    private final NotaDAO dao = new NotaDAO();
    private final ObservableList<Nota> items = FXCollections.observableArrayList();
    private Nota seleccionada = null;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listNotas.setItems(items);

        listNotas.setCellFactory(lv -> new ListCell<>() {
            @Override protected void updateItem(Nota item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                setText((item.isFijada() ? "📌 " : "📝 ") + item.getTitulo());
                setStyle(item.isFijada() ? "-fx-font-weight: bold;" : "");
            }
        });

        listNotas.getSelectionModel().selectedItemProperty().addListener((obs, old, nota) -> {
            if (nota != null) mostrarNota(nota);
        });

        loadAll();
    }

    private void loadAll() {
        items.setAll(dao.findAll());
    }

    private void mostrarNota(Nota n) {
        seleccionada = n;
        fTitulo.setText(n.getTitulo());
        fContenido.setText(n.getContenido());
        fEtiquetas.setText(n.getEtiquetas());
        fFijada.setSelected(n.isFijada());
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) loadAll();
        else items.setAll(dao.search(q));
    }

    @FXML private void onNuevo() {
        seleccionada = null;
        fTitulo.clear(); fContenido.clear();
        fEtiquetas.clear(); fFijada.setSelected(false);
        fTitulo.requestFocus();
        listNotas.getSelectionModel().clearSelection();
    }

    @FXML private void onGuardar() {
        if (fTitulo.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "El título es obligatorio").showAndWait();
            return;
        }
        if (seleccionada == null) seleccionada = new Nota();
        seleccionada.setTitulo(fTitulo.getText().trim());
        seleccionada.setContenido(fContenido.getText());
        seleccionada.setEtiquetas(fEtiquetas.getText().trim());
        seleccionada.setFijada(fFijada.isSelected());

        if (seleccionada.getId() == 0) dao.insert(seleccionada);
        else                           dao.update(seleccionada);
        loadAll();
    }

    @FXML private void onEliminar() {
        if (seleccionada == null || seleccionada.getId() == 0) return;
        new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar esta nota?", ButtonType.YES, ButtonType.NO)
            .showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) {
                    dao.delete(seleccionada.getId());
                    seleccionada = null;
                    fTitulo.clear(); fContenido.clear(); fEtiquetas.clear();
                    loadAll();
                }
            });
    }
}
