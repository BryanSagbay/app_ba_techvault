package com.sysops.controllers;

import com.sysops.config.DatabaseConfig;
import com.sysops.models.PasswordEntry;
import com.sysops.modules.passwords.PasswordDAO;
import com.sysops.utils.CryptoUtil;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

public class PasswordController implements Initializable {

    // Bloqueo
    @FXML private VBox paneBlocked, paneVault;
    @FXML private PasswordField pfMaster;
    @FXML private Label lblMasterError;

    // Vault
    @FXML private TextField txtBuscar;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private TableView<PasswordEntry> tabla;
    @FXML private TableColumn<PasswordEntry,String> colNombre, colUsuario, colPassword, colUrl, colCategoria;
    @FXML private TableColumn<PasswordEntry,Void>   colAcciones;
    @FXML private TitledPane paneForm;

    // Formulario
    @FXML private TextField     fNombre, fUsuario, fUrl;
    @FXML private PasswordField fPassword;
    @FXML private ComboBox<String> fCategoria;
    @FXML private TextArea      fNotas;

    private final PasswordDAO dao = new PasswordDAO();
    private final ObservableList<PasswordEntry> items = FXCollections.observableArrayList();
    private char[] masterPassword = null;
    private PasswordEntry editando = null;
    private Timer autoLockTimer;

    // Auto-ocultar contraseñas mostradas después de 30 seg
    private static final long AUTO_LOCK_DELAY_MS = 5 * 60 * 1000L; // 5 minutos

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupTable();
        setupCombos();
    }

    @FXML
    private void onUnlock() {
        String pwd = pfMaster.getText();
        if (pwd.isBlank()) return;

        char[] inputPwd = pwd.toCharArray();
        try {
            var jdbi = DatabaseConfig.getJdbi();
            Optional<String> stored = jdbi.withHandle(h ->
                h.createQuery("SELECT valor FROM configuracion WHERE clave = 'master_password_hash'")
                 .mapTo(String.class).findFirst()
            );

            if (stored.isEmpty()) {
                // Primera vez: registrar contraseña maestra
                String hash = CryptoUtil.hashMasterPassword(inputPwd);
                jdbi.withHandle(h ->
                    h.createUpdate("INSERT INTO configuracion (clave, valor) VALUES ('master_password_hash', :h)")
                     .bind("h", hash).execute()
                );
                masterPassword = inputPwd;
                unlockVault();
            } else {
                if (CryptoUtil.verifyMasterPassword(inputPwd, stored.get())) {
                    masterPassword = inputPwd;
                    unlockVault();
                } else {
                    lblMasterError.setText("❌ Contraseña incorrecta");
                    lblMasterError.setVisible(true);
                    pfMaster.clear();
                }
            }
        } catch (Exception e) {
            lblMasterError.setText("Error: " + e.getMessage());
            lblMasterError.setVisible(true);
        }
    }

    private void unlockVault() {
        pfMaster.clear();
        lblMasterError.setVisible(false);
        paneBlocked.setVisible(false);
        paneBlocked.setManaged(false);
        paneVault.setVisible(true);
        paneVault.setManaged(true);
        loadAll();
        startAutoLockTimer();
    }

    @FXML
    private void onLock() {
        // Limpiar master password de memoria
        if (masterPassword != null) {
            java.util.Arrays.fill(masterPassword, '\0');
            masterPassword = null;
        }
        items.forEach(PasswordEntry::clearPasswordPlain);
        if (autoLockTimer != null) autoLockTimer.cancel();

        paneVault.setVisible(false);
        paneVault.setManaged(false);
        paneBlocked.setVisible(true);
        paneBlocked.setManaged(true);
    }

    private void startAutoLockTimer() {
        if (autoLockTimer != null) autoLockTimer.cancel();
        autoLockTimer = new Timer(true);
        autoLockTimer.schedule(new TimerTask() {
            @Override public void run() {
                Platform.runLater(() -> onLock());
            }
        }, AUTO_LOCK_DELAY_MS);
    }

    private void setupTable() {
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colUsuario.setCellValueFactory(new PropertyValueFactory<>("usuario"));
        colUrl.setCellValueFactory(new PropertyValueFactory<>("url"));
        colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));

        // Columna password: muestra "*****" o el valor si está desencriptado
        colPassword.setCellFactory(col -> new TableCell<>() {
            final Button btnVer = new Button("👁 Ver");
            {
                btnVer.setStyle("-fx-background-color: #333; -fx-text-fill: #ccc; -fx-cursor: hand; -fx-font-size: 11px;");
                btnVer.setOnAction(e -> {
                    PasswordEntry entry = getTableRow().getItem();
                    if (entry == null) return;
                    if (entry.getPasswordPlain() != null) {
                        // Ya desencriptado → copiar al portapapeles
                        javafx.scene.input.Clipboard cb = javafx.scene.input.Clipboard.getSystemClipboard();
                        javafx.scene.input.ClipboardContent cc = new javafx.scene.input.ClipboardContent();
                        cc.putString(entry.getPasswordPlain());
                        cb.setContent(cc);
                        btnVer.setText("✅ Copiado");
                        new Timer(true).schedule(new TimerTask() {
                            @Override public void run() { Platform.runLater(() -> btnVer.setText("👁 Ver")); }
                        }, 2000);
                    } else {
                        // Desencriptar
                        try {
                            Optional<PasswordEntry> dec = dao.findByIdDecrypted(entry.getId(), masterPassword);
                            dec.ifPresent(d -> {
                                entry.setPasswordPlain(d.getPasswordPlain());
                                tabla.refresh();
                                // Auto-ocultar en 30 segundos
                                new Timer(true).schedule(new TimerTask() {
                                    @Override public void run() {
                                        Platform.runLater(() -> {
                                            entry.clearPasswordPlain();
                                            tabla.refresh();
                                        });
                                    }
                                }, 30_000);
                            });
                        } catch (Exception ex) {
                            new Alert(Alert.AlertType.ERROR, "Error al desencriptar").showAndWait();
                        }
                    }
                });
            }
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); setText(null); return; }
                PasswordEntry entry = getTableRow().getItem();
                if (entry != null && entry.getPasswordPlain() != null) {
                    setText(entry.getPasswordPlain());
                    setGraphic(btnVer);
                } else {
                    setText("••••••••");
                    setGraphic(btnVer);
                }
            }
        });

        // Acciones
        colAcciones.setCellFactory(col -> new TableCell<>() {
            final Button btnEdit = new Button("✏");
            final Button btnDel  = new Button("🗑");
            final HBox box = new HBox(6, btnEdit, btnDel);
            {
                btnEdit.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: white; -fx-cursor: hand;");
                btnDel.setStyle("-fx-background-color: #c62828; -fx-text-fill: white; -fx-cursor: hand;");
                btnEdit.setOnAction(e -> editarItem(getTableRow().getItem()));
                btnDel.setOnAction(e -> eliminarItem(getTableRow().getItem()));
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });

        tabla.setItems(items);
    }

    private void setupCombos() {
        var cats = FXCollections.observableArrayList(
                "Servidores", "Bases de Datos", "Aplicaciones", "VPN", "Correo", "Otro");
        cmbCategoria.setItems(FXCollections.observableArrayList("TODAS"));
        cmbCategoria.getItems().addAll(cats);
        cmbCategoria.setValue("TODAS");
        cmbCategoria.setOnAction(e -> loadAll());

        fCategoria.setItems(cats);
    }

    private void loadAll() {
        List<PasswordEntry> all = dao.findAll();
        String cat = cmbCategoria.getValue();
        if (!"TODAS".equals(cat)) {
            all = all.stream().filter(p -> cat.equals(p.getCategoria())).toList();
        }
        items.setAll(all);
    }

    @FXML private void onBuscar() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) loadAll();
        else items.setAll(dao.search(q));
    }

    @FXML private void onNuevo() {
        editando = null;
        clearForm();
        paneForm.setExpanded(true);
        paneForm.setText("Nueva Entrada");
    }

    private void editarItem(PasswordEntry p) {
        if (p == null) return;
        editando = p;
        fNombre.setText(p.getNombre());
        fUsuario.setText(p.getUsuario());
        fUrl.setText(p.getUrl());
        fCategoria.setValue(p.getCategoria());
        fNotas.setText(p.getNotas());
        fPassword.setText("");   // No pre-rellenar
        paneForm.setExpanded(true);
        paneForm.setText("Editar — " + p.getNombre());
    }

    private void eliminarItem(PasswordEntry p) {
        if (p == null) return;
        new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar \"" + p.getNombre() + "\"?",
                  ButtonType.YES, ButtonType.NO)
            .showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) { dao.delete(p.getId()); loadAll(); }
            });
    }

    @FXML private void onGuardar() {
        if (fNombre.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "El nombre es obligatorio").showAndWait();
            return;
        }
        if (editando == null && fPassword.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "La contraseña es obligatoria").showAndWait();
            return;
        }
        try {
            PasswordEntry p = editando != null ? editando : new PasswordEntry();
            p.setNombre(fNombre.getText().trim());
            p.setUsuario(fUsuario.getText().trim());
            p.setUrl(fUrl.getText().trim());
            p.setCategoria(fCategoria.getValue());
            p.setNotas(fNotas.getText().trim());

            if (!fPassword.getText().isBlank()) {
                p.setPasswordPlain(fPassword.getText());
            }

            if (editando == null) dao.insert(p, masterPassword);
            else                  dao.update(p, masterPassword);

            loadAll();
            paneForm.setExpanded(false);
            clearForm();
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Error guardando: " + e.getMessage()).showAndWait();
        }
    }

    @FXML private void onCancelar() {
        paneForm.setExpanded(false);
        clearForm();
    }

    @FXML private void onTogglePassword() {
        // Implementar toggle show/hide en PasswordField
        // JavaFX requiere TextField adicional para esto
    }

    @FXML private void onGenerarPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
        SecureRandom rng = new SecureRandom();
        StringBuilder sb = new StringBuilder(20);
        for (int i = 0; i < 20; i++) sb.append(chars.charAt(rng.nextInt(chars.length())));
        fPassword.setText(sb.toString());
    }

    private void clearForm() {
        fNombre.clear(); fUsuario.clear(); fUrl.clear();
        fPassword.clear(); fNotas.clear();
        fCategoria.setValue(null);
        editando = null;
    }
}
