package com.sysops.models;

// ═══════════════════════════════════════════════════════════════
//  PASSWORD ENTRY
// ═══════════════════════════════════════════════════════════════
public class PasswordEntry {
    private int id;
    private String nombre;
    private String usuario;
    private String passwordEnc;   // Encriptado AES-256 en BD
    private String passwordPlain; // Solo en memoria, nunca persiste
    private String url;
    private String categoria;
    private String notas;
    private String creadoEn;
    private String actualizadoEn;

    public PasswordEntry() {}

    public int getId()                          { return id; }
    public void setId(int id)                   { this.id = id; }
    public String getNombre()                   { return nombre; }
    public void setNombre(String n)             { this.nombre = n; }
    public String getUsuario()                  { return usuario; }
    public void setUsuario(String u)            { this.usuario = u; }
    public String getPasswordEnc()              { return passwordEnc; }
    public void setPasswordEnc(String p)        { this.passwordEnc = p; }
    public String getPasswordPlain()            { return passwordPlain; }
    public void setPasswordPlain(String p)      { this.passwordPlain = p; }
    public void clearPasswordPlain()            { this.passwordPlain = null; }
    public String getUrl()                      { return url; }
    public void setUrl(String u)                { this.url = u; }
    public String getCategoria()                { return categoria; }
    public void setCategoria(String c)          { this.categoria = c; }
    public String getNotas()                    { return notas; }
    public void setNotas(String n)              { this.notas = n; }
    public String getCreadoEn()                 { return creadoEn; }
    public void setCreadoEn(String c)           { this.creadoEn = c; }
    public String getActualizadoEn()            { return actualizadoEn; }
    public void setActualizadoEn(String a)      { this.actualizadoEn = a; }

    @Override
    public String toString() { return nombre + " (" + usuario + ")"; }
}
