package com.sysops.models;

// ═══════════════════════════════════════════════════════════════
//  NOTA
// ═══════════════════════════════════════════════════════════════
public class Nota {
    private int id;
    private String titulo;
    private String contenido;
    private String etiquetas;
    private String color;
    private boolean fijada;
    private String creadoEn;
    private String actualizadoEn;

    public Nota() {}

    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }
    public String getTitulo()               { return titulo; }
    public void setTitulo(String t)         { this.titulo = t; }
    public String getContenido()            { return contenido; }
    public void setContenido(String c)      { this.contenido = c; }
    public String getEtiquetas()            { return etiquetas; }
    public void setEtiquetas(String e)      { this.etiquetas = e; }
    public String getColor()                { return color; }
    public void setColor(String c)          { this.color = c; }
    public boolean isFijada()               { return fijada; }
    public void setFijada(boolean f)        { this.fijada = f; }
    public String getCreadoEn()             { return creadoEn; }
    public void setCreadoEn(String c)       { this.creadoEn = c; }
    public String getActualizadoEn()        { return actualizadoEn; }
    public void setActualizadoEn(String a)  { this.actualizadoEn = a; }

    @Override
    public String toString() { return titulo; }
}
