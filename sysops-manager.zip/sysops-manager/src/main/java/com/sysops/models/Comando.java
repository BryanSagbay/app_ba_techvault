package com.sysops.models;

public class Comando {
    private int id;
    private String nombre;
    private String comando;
    private String descripcion;
    private String categoria;
    private String sistemaOp;
    private String etiquetas;
    private String creadoEn;

    public Comando() {}

    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }
    public String getNombre()               { return nombre; }
    public void setNombre(String n)         { this.nombre = n; }
    public String getComando()              { return comando; }
    public void setComando(String c)        { this.comando = c; }
    public String getDescripcion()          { return descripcion; }
    public void setDescripcion(String d)    { this.descripcion = d; }
    public String getCategoria()            { return categoria; }
    public void setCategoria(String c)      { this.categoria = c; }
    public String getSistemaOp()            { return sistemaOp; }
    public void setSistemaOp(String s)      { this.sistemaOp = s; }
    public String getEtiquetas()            { return etiquetas; }
    public void setEtiquetas(String e)      { this.etiquetas = e; }
    public String getCreadoEn()             { return creadoEn; }
    public void setCreadoEn(String c)       { this.creadoEn = c; }

    @Override
    public String toString() { return nombre; }
}
