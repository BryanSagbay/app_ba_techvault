package com.sysops.models;

import java.time.LocalDateTime;

// ═══════════════════════════════════════════════════════════════
//  CORRECTIVO
// ═══════════════════════════════════════════════════════════════
public class Correctivo {
    private int id;
    private String ticket;
    private String titulo;
    private String descripcion;
    private String solucion;
    private String servidor;
    private String ambiente;
    private String estado;        // ABIERTO, EN_PROCESO, RESUELTO, CERRADO
    private String prioridad;     // BAJA, MEDIA, ALTA, CRITICA
    private String fechaInicio;
    private String fechaCierre;
    private String tiempoResolucion;
    private String etiquetas;
    private String creadoEn;

    public Correctivo() {}

    // Getters y Setters
    public int getId()                          { return id; }
    public void setId(int id)                   { this.id = id; }
    public String getTicket()                   { return ticket; }
    public void setTicket(String ticket)        { this.ticket = ticket; }
    public String getTitulo()                   { return titulo; }
    public void setTitulo(String titulo)        { this.titulo = titulo; }
    public String getDescripcion()              { return descripcion; }
    public void setDescripcion(String d)        { this.descripcion = d; }
    public String getSolucion()                 { return solucion; }
    public void setSolucion(String s)           { this.solucion = s; }
    public String getServidor()                 { return servidor; }
    public void setServidor(String s)           { this.servidor = s; }
    public String getAmbiente()                 { return ambiente; }
    public void setAmbiente(String a)           { this.ambiente = a; }
    public String getEstado()                   { return estado; }
    public void setEstado(String e)             { this.estado = e; }
    public String getPrioridad()                { return prioridad; }
    public void setPrioridad(String p)          { this.prioridad = p; }
    public String getFechaInicio()              { return fechaInicio; }
    public void setFechaInicio(String f)        { this.fechaInicio = f; }
    public String getFechaCierre()              { return fechaCierre; }
    public void setFechaCierre(String f)        { this.fechaCierre = f; }
    public String getTiempoResolucion()         { return tiempoResolucion; }
    public void setTiempoResolucion(String t)   { this.tiempoResolucion = t; }
    public String getEtiquetas()                { return etiquetas; }
    public void setEtiquetas(String e)          { this.etiquetas = e; }
    public String getCreadoEn()                 { return creadoEn; }
    public void setCreadoEn(String c)           { this.creadoEn = c; }

    @Override
    public String toString() { return "[" + ticket + "] " + titulo; }
}
