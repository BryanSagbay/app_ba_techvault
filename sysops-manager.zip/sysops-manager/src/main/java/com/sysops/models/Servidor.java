package com.sysops.models;

public class Servidor {
    private int id;
    private String nombre;
    private String ip;
    private String ambiente;   // PRD, QA, DEV, HOM
    private String tipo;       // APP, BD, WEB, PROXY, etc.
    private int puerto;
    private String so;         // Linux, Windows Server, etc.
    private String descripcion;
    private String usuario;
    private String notas;
    private boolean activo;
    private String creadoEn;

    public Servidor() {}

    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }
    public String getNombre()               { return nombre; }
    public void setNombre(String n)         { this.nombre = n; }
    public String getIp()                   { return ip; }
    public void setIp(String ip)            { this.ip = ip; }
    public String getAmbiente()             { return ambiente; }
    public void setAmbiente(String a)       { this.ambiente = a; }
    public String getTipo()                 { return tipo; }
    public void setTipo(String t)           { this.tipo = t; }
    public int getPuerto()                  { return puerto; }
    public void setPuerto(int p)            { this.puerto = p; }
    public String getSo()                   { return so; }
    public void setSo(String s)             { this.so = s; }
    public String getDescripcion()          { return descripcion; }
    public void setDescripcion(String d)    { this.descripcion = d; }
    public String getUsuario()              { return usuario; }
    public void setUsuario(String u)        { this.usuario = u; }
    public String getNotas()                { return notas; }
    public void setNotas(String n)          { this.notas = n; }
    public boolean isActivo()               { return activo; }
    public void setActivo(boolean a)        { this.activo = a; }
    public String getCreadoEn()             { return creadoEn; }
    public void setCreadoEn(String c)       { this.creadoEn = c; }

    @Override
    public String toString() { return nombre + " (" + ip + ")"; }
}
