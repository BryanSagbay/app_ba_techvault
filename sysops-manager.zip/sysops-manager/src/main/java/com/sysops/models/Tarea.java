package com.sysops.models;

public class Tarea {
    private int id;
    private String titulo;
    private String descripcion;
    private String prioridad;    // BAJA, MEDIA, ALTA, URGENTE
    private String estado;       // PENDIENTE, EN_PROCESO, COMPLETADA, CANCELADA
    private String categoria;
    private String fechaLimite;
    private String completadaEn;
    private String creadoEn;

    public Tarea() {}

    public int getId()                      { return id; }
    public void setId(int id)               { this.id = id; }
    public String getTitulo()               { return titulo; }
    public void setTitulo(String t)         { this.titulo = t; }
    public String getDescripcion()          { return descripcion; }
    public void setDescripcion(String d)    { this.descripcion = d; }
    public String getPrioridad()            { return prioridad; }
    public void setPrioridad(String p)      { this.prioridad = p; }
    public String getEstado()               { return estado; }
    public void setEstado(String e)         { this.estado = e; }
    public String getCategoria()            { return categoria; }
    public void setCategoria(String c)      { this.categoria = c; }
    public String getFechaLimite()          { return fechaLimite; }
    public void setFechaLimite(String f)    { this.fechaLimite = f; }
    public String getCompletadaEn()         { return completadaEn; }
    public void setCompletadaEn(String c)   { this.completadaEn = c; }
    public String getCreadoEn()             { return creadoEn; }
    public void setCreadoEn(String c)       { this.creadoEn = c; }

    public boolean isCompletada() { return "COMPLETADA".equals(estado); }

    @Override
    public String toString() { return titulo; }
}
