package com.sysops.config;

import com.sysops.App;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.sqlite.SQLiteConfig;
import org.sqlite.SQLiteDataSource;

import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConfig {

    private static Jdbi jdbi;
    private static SQLiteDataSource dataSource;

    public static void initialize() {
        String dbPath = App.DATA_DIR.resolve("sysops.db").toString();

        try {
            // Configurar SQLite con WAL y foreign keys desde el DataSource
            SQLiteConfig config = new SQLiteConfig();
            config.setJournalMode(SQLiteConfig.JournalMode.WAL);
            config.enforceForeignKeys(true);
            config.setBusyTimeout(5000); // esperar 5 seg si BD ocupada

            dataSource = new SQLiteDataSource(config);
            dataSource.setUrl("jdbc:sqlite:" + dbPath);

            // JDBI usa el DataSource — una sola fuente de conexiones
            jdbi = Jdbi.create(dataSource);
            jdbi.installPlugin(new SqlObjectPlugin());

            // Crear tablas usando JDBI directamente (sin conexión separada)
            createTables();
            System.out.println("[DB] Base de datos inicializada: " + dbPath);
        } catch (Exception e) {
            System.err.println("[DB] Error: " + e.getMessage());
            throw new RuntimeException("No se pudo inicializar la base de datos", e);
        }
    }

    private static void createTables() {
        jdbi.useHandle(handle -> {
        Statement stmt = handle.getConnection().createStatement();
        try {

            // ── CONFIGURACIÓN ──────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS configuracion (
                    clave   TEXT PRIMARY KEY,
                    valor   TEXT NOT NULL
                )
            """);

            // ── CORRECTIVOS ────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS correctivos (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    ticket          TEXT,
                    titulo          TEXT NOT NULL,
                    descripcion     TEXT,
                    solucion        TEXT,
                    servidor        TEXT,
                    ambiente        TEXT,
                    estado          TEXT DEFAULT 'ABIERTO',
                    prioridad       TEXT DEFAULT 'MEDIA',
                    fecha_inicio    TEXT,
                    fecha_cierre    TEXT,
                    tiempo_resolucion TEXT,
                    etiquetas       TEXT,
                    creado_en       TEXT DEFAULT (datetime('now','localtime')),
                    actualizado_en  TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            // ── SERVIDORES ─────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS servidores (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre      TEXT NOT NULL,
                    ip          TEXT NOT NULL,
                    ambiente    TEXT,
                    tipo        TEXT,
                    puerto      INTEGER,
                    so          TEXT,
                    descripcion TEXT,
                    usuario     TEXT,
                    notas       TEXT,
                    activo      INTEGER DEFAULT 1,
                    creado_en   TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            // ── CONTRASEÑAS (encriptado AES-256) ───────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS passwords (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre       TEXT NOT NULL,
                    usuario      TEXT,
                    password_enc BLOB NOT NULL,
                    url          TEXT,
                    categoria    TEXT,
                    notas        TEXT,
                    creado_en    TEXT DEFAULT (datetime('now','localtime')),
                    actualizado_en TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            // ── TAREAS ─────────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS tareas (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    titulo          TEXT NOT NULL,
                    descripcion     TEXT,
                    prioridad       TEXT DEFAULT 'MEDIA',
                    estado          TEXT DEFAULT 'PENDIENTE',
                    categoria       TEXT,
                    fecha_limite    TEXT,
                    completada_en   TEXT,
                    creado_en       TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            // ── NOTAS ──────────────────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS notas (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    titulo      TEXT NOT NULL,
                    contenido   TEXT,
                    etiquetas   TEXT,
                    color       TEXT DEFAULT '#1e3a5f',
                    fijada      INTEGER DEFAULT 0,
                    creado_en   TEXT DEFAULT (datetime('now','localtime')),
                    actualizado_en TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            // ── COMANDOS / MANUALES ────────────────────────────────────
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS comandos (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre      TEXT NOT NULL,
                    comando     TEXT NOT NULL,
                    descripcion TEXT,
                    categoria   TEXT,
                    sistema_op  TEXT,
                    etiquetas   TEXT,
                    creado_en   TEXT DEFAULT (datetime('now','localtime'))
                )
            """);

            System.out.println("[DB] Tablas verificadas/creadas correctamente");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        }); // fin useHandle
    }

    public static Jdbi getJdbi() {
        if (jdbi == null) throw new IllegalStateException("Base de datos no inicializada");
        return jdbi;
    }

    public static void close() {
        // SQLiteDataSource cierra conexiones automáticamente
        System.out.println("[DB] Conexión cerrada");
    }
}
