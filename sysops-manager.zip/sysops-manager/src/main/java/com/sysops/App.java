package com.sysops;

import atlantafx.base.theme.PrimerDark;
import com.sysops.config.DatabaseConfig;
import com.sysops.controllers.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App extends Application {

    public static final String APP_NAME = "SysOps Manager";
    public static final String VERSION  = "1.0.0";

    // Directorio base de datos en carpeta del usuario
    public static final Path DATA_DIR = Paths.get(
            System.getProperty("user.home"), ".sysops-manager"
    );

    @Override
    public void start(Stage stage) throws IOException {
        // Crear directorio de datos si no existe
        Files.createDirectories(DATA_DIR);

        // Inicializar base de datos
        DatabaseConfig.initialize();

        // Aplicar tema oscuro AtlantaFX
        Application.setUserAgentStylesheet(new PrimerDark().getUserAgentStylesheet());

        // Cargar pantalla principal
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/MainView.fxml")
        );
        Scene scene = new Scene(loader.load(), 1280, 780);
        scene.getStylesheets().add(
                getClass().getResource("/css/app.css").toExternalForm()
        );

        stage.setTitle(APP_NAME + " v" + VERSION);
        stage.setScene(scene);
        stage.setMinWidth(1000);
        stage.setMinHeight(650);
        stage.show();

        // Controlador principal
        MainController controller = loader.getController();
        controller.initializeApp(stage);
    }

    @Override
    public void stop() {
        DatabaseConfig.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
