module com.sysops {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires org.xerial.sqlitejdbc;
    requires org.jdbi.v3.core;
    requires org.jdbi.v3.sqlobject;
    requires atlantafx.base;
    requires com.fasterxml.jackson.databind;
    requires org.slf4j;
    requires org.slf4j.simple;

    opens com.sysops            to javafx.fxml;
    opens com.sysops.controllers to javafx.fxml;
    opens com.sysops.models      to javafx.base, org.jdbi.v3.core;
    opens com.sysops.config      to javafx.fxml;

    exports com.sysops;
    exports com.sysops.controllers;
    exports com.sysops.models;
}
